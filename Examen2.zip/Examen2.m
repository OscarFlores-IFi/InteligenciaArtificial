%% Ejercicio 3
data = xlsread('DatosEx2.xls','Delfines')
X = data(:,2:end)
Y = data(:,1)

X1 = X(:,1)
X2 = X(:,2)


%% Para las hembras
Xh = X1(X2==0)
Yh = Y(X2==0)
test = [37]
ngrado = 1
Xha = func_polinomio(Xh,ngrado) % Se ajusta un modelo de grado 1
Test = func_polinomio(test,ngrado)

% Ajuste por m�nimos cuadrados
Wh = pinv(Xha'*Xha)*Xha'*Yh;
% Predicci�n. 
pred = Test*Wh



%% Para los machos
Xm = X1(X2==1)
Ym = Y(X2==1)
ngrado = 1
Xma = func_polinomio(Xm,ngrado) % Se ajusta un modelo de grado 1

% Ajuste por m�nimos cuadrados
Wm = pinv(Xma'*Xma)*Xma'*Ym;

%% Modelo propuesto 
Xpr = [ones(size(X1)) X1 X1.^2 X2 X1.^2.*X2]
Wpr = pinv(Xpr'*Xpr)*Xpr'*Y;

%% Hembra 37 a�os. 
W = pinv(X'*X)*X'*Y









%% Ejercicio 5.
data = readtable('hapiness.txt'); %Carga los datos del archivo

%% a, b, c
X = [data.X2 data.X4 data.X5];
Y = data.D;
test = [4 5 2] % Ser� utilizado para el inciso c)

% Regresi�n log�stica. 
ngrado = 3
Xa=func_polinomio(X,ngrado);
Test = func_polinomio(test,ngrado); 


W=zeros(size(Xa,2),1); %Pesos iniciales
[J,dJdW]=fun_costob(W,Xa,Y); %Calculo de J y W
options=optimset('GradObj','on','MaxIter',1000);
[Wopt,Jopt]=fminunc(@(W)fun_costob(W,Xa,Y),W,options);


V=Xa*Wopt;
Yg=1./(1+exp(-V));
Yg=round(Yg);


[Accu Prec Rec] = desempenio(Yg,Y)
conf = confusionmat(Yg,Y)
% confusionchart(conf) % no funciona... no se por qu�. 

% Predicci�n. 
pred=1./(1+exp(-Test*Wopt));
Pred=round(pred);
%% d, e, f
X = data{:,2:end};
Y = data.D;
test = [3 4 1 5 2 3]; % Ser� utilizado para el inciso c)

% Regresi�n log�stica. 
ngrado = 2
Xa=func_polinomio(X,ngrado);
Test = func_polinomio(test,ngrado); 


W=zeros(size(Xa,2),1); %Pesos iniciales
[J,dJdW]=fun_costob(W,Xa,Y); %Calculo de J y W
options=optimset('GradObj','on','MaxIter',1000);
[Wopt,Jopt]=fminunc(@(W)fun_costob(W,Xa,Y),W,options);


V=Xa*Wopt;
Yg=1./(1+exp(-V));
Yg=round(Yg);


[Accu Prec Rec] = desempenio(Yg,Y)
conf = confusionmat(Yg,Y)
% confusionchart(conf) % no funciona... no se por qu�. 

% Predicci�n. 
pred=1./(1+exp(-Test*Wopt));
Pred=round(pred);










%% Ejercicio 6

clc;
clear all;
close all;
%%
data = xlsread('base_semillas.xlsx')
data = data';
test = xlsread('base_semillas.xlsx','clasifica')
test = test';
%% Entrenamiento de la red. 
Iteraciones = 10

Jcost = zeros(Iteraciones,1);
NNN = zeros(Iteraciones,1);
for iter=2:size(Jcost)+1
    neuronas = iter;
    red = competlayer(neuronas);
    red.trainParam.epochs = 50;
    red = train(red,data) ;
    
    % Calculo de J 
    [J, i] = CalculoJ(data,red)
    Jcost(iter-1) = J
    NNN(iter-1) = i
end
%%
Jcost_escala = (1+(Jcost-max(Jcost))/((max(Jcost)-min(Jcost))))*(max(NNN)-min(NNN))+min(NNN)
plot([2:Iteraciones+1],Jcost_escala,'r',[2:Iteraciones+1],NNN,'b*')
%%
plot([2:Iteraciones+1],NNN)
%% Elejimos cantidad de Neuronas para la clasificaci�n. 

neuronas = 3; %cambiar de acuerdo a grafica de codo
red = competlayer(neuronas);
red.trainParam.epochs = 250; 
red = train(red,data) ;

% Encontrar la cantidad de elementos en cada grupo
EpG = sum(red(data),2)

% Calcular J 
[J, i] = CalculoJ(data,red)

%% Evaluar los datos de prueba
test_groups = vec2ind(red(test))


















