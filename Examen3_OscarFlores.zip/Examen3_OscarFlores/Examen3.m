%% Repaso Parcial 3.


%% Problema 1
clear
clc
load qsar_fish_toxicity.txt
data = qsar_fish_toxicity

X = data(:,1:end-1)
Y = data(:,end)
%% Seleccion de datos de entrenamiento
ndat = round(0.85*size(Y,1));

Xtrain = X(1:ndat,:);
Ytrain = Y(1:ndat,:);

Xtest = X(ndat+1:end,:);
Ytest = Y(ndat+1:end,:);

%% Entrenamiento
red=feedforwardnet([10 10 10]);
red.trainFcn='trainlm'
red=train(red,Xtrain',Ytrain');


%
Ygtest = red(Xtest'); 
Yg = red(X')

scatter(Yg, Y, 'k*') %Graficamos los datos predichos vs los reales. 
xlabel('Yg')
ylabel('Y')
title('Yg vs Y')
hold on
scatter(Ygtest, Ytest, 'ro')
hold off
perform(red,Y',Yg')
perform(red,(Ygtest'),Ytest')
%% Valuaci�n de una casa basado en los parametros espec�ficados. 
X1= 2.53
X2=0.754
X3=1.115
X4=2
X5=1
X6=1.634

pred = [X1 X2 X3 X4 X5 X6]';
estimacion = red(pred)


%% Problema 2
clear
clc
load WifiData.mat

%%
data=WifiData';

X=data(1:end-1,:);
Y=data(end,:);

ndat=round(0.75*size(Y,2)); %Cantidad de datos para entrenar (75%)

Ytrain=Y(1:ndat);
Xtrain=X(:,1:ndat);

Ytest = Y(ndat+1:end);
Xtest = X(:,ndat+1:end);
%% Creacion del modelo neuronal
red=feedforwardnet([10 10 10]);
red.trainFcn='trainrp' % se puede usar 'trainscg' o 'trainrp'
red=train(red,Xtrain,Ytrain);

%% Simulacion
% Yg=round(red(X));
pred = round(red(Xtest))
scatter(pred,Ytest)




%%
cv = cvpartition(Y,'holdout',0.2);
Xtrain = X(:,training(cv));
Ytrain = Y(training(cv));
Xtest = X(:,test(cv));
Ytest = Y(test(cv));

%% Creaci?n del modelo neuronal
red=feedforwardnet([10 10 10]);
red.trainFcn='trainrp' % se puede usar 'trainscg' o 'trainrp'
red=train(red,Xtrain,Ytrain);

%% Simulacion
% Yg=round(red(X));
Ygtest = round(red(Xtest))
confusionmat(Ytest,Ygtest)
perform(red,Ytest,Ygtest)

%%
clasificacion = [-46 -54 -47 -51 -57 -80 -73; -62 -50 -45 -60 -40 -80 -77; -15	-20	-40	-50	-30	-70	-80]
red(clasificacion')





%%
cv = cvpartition(Y,'holdout',0.2);
Y = full(ind2vec(Y));
Xtrain = X(:,training(cv));
Ytrain = Y(:,training(cv));
Xtest = X(:,test(cv));
Ytest = Y(:,test(cv));

%% Creaci?n del modelo neuronal
red=feedforwardnet([10 10 10]);
red.trainFcn='trainrp' % se puede usar 'trainscg' o 'trainrp'
red=train(red,Xtrain,Ytrain);

%% Simulacion
% Yg=round(red(X));
Ygtest = round(red(Xtest))
confusionmat(vec2ind(Ytest),vec2ind(Ygtest))
perform(red,Ytest,Ygtest)

%%
clasificacion = [-46 -54 -47 -51 -57 -80 -73; -62 -50 -45 -60 -40 -80 -77; -15	-20	-40	-50	-30	-70	-80]
red(clasificacion')

